
# Server Report

Timestamp: 2023-08-16 18:46:38
Server Name: Web server
IP Address: 192.168.1.100
Operating system: Ubuntu
Status: Active