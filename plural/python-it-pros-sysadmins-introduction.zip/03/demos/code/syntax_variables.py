age  = 25
name = "Ed"
height = 190.0

x = 10
y = 5
sum = x + y
product = x * y
division = x / y

first_name = "Ed"
last_name = "Freitas"
full_name = first_name + last_name

counter = 1
counter = counter + 1

name = "Alexandra"
age = 36
print("Name: ", name)
print("Age: ", age)

name = "Ed"
age = 22
message = f"My name is {name} and I am {age} years old"
print(message)

# This is a one-line comment

"""
This is a multi-line
comment, also known as a docstring
"""