import my_module as m
import math

m.hello("Ed")
r = m.add(3, 4)
print("Sum: ", r)

print("The value of pi is: ", math.pi)
print("Sq root of 25 is: ", math.sqrt(25))