def hello(name):
    print(f"Hi, {name}!")

def add(a, b):
    return a + b